import React from "react";

function Topnav() {
  return (
    <div className="bg-black text-light">
      <div className="container">
        <nav className="navbar ">
          <div className="container-fluid">
            <p className="text-light">
              (GMT+5.5) 19:14:25
            </p>
            <div className="d-flex gap-4 ">
              <p>24*7 Support</p>
              <p>Facebook</p>
              <p>Email</p>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}

export default Topnav;
