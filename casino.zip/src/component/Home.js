import React from 'react';
import Content from './Content';
import Navbar from '../component/Navbar'
function Home() {
  return (
    <>
    <Navbar />
    
    <Content/>
    </>
  );
}

export default Home;
