import { BrowserRouter, Route, Routes } from "react-router-dom";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min";
import "./App.css";

import Header from "./component/Header";

import Topnav from "./component/Topnav";
import About from "./component/About";
import Home from "./component/Home";
import Footer from "./component/Footer";
import Login from "./component/Login";
import Signup from "./component/Signup";

function App() {
  return (
    <>
      <BrowserRouter>
        <Topnav />
        <Header />
        <Routes>
          <Route path="/about" Component={About} />
          <Route path="/login" Component={Login} />
          <Route path="/signup" Component={Signup} />
          <Route path="/" Component={Home} />
          <Route path="*" element={<h1 className="text-center py-5 my-5">404 Not Found</h1>}/>  
        </Routes>

        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
